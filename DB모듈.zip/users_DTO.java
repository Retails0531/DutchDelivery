
public class users_DTO {
String id,pw,phonenumber,reginumber,email,name,cur_coordinate,nickname,profileURL;
	
	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public String getPw() {
		return pw;
	}
	
	public void setPw(String pw) {
		this.pw = pw;
	}
	
	public String getPhonenumber() {
		return phonenumber;
	}
	
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}
	
	public String getReginumber() {
		return reginumber;
	}
		
	public void setReginumber(String reginumber) {
		this.reginumber = reginumber;
	}	
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getCoordinate() {
		return cur_coordinate;
	}
	
	public void setCoordinate(String coordinate) {
		this.cur_coordinate = coordinate;
	}
	
	public String getNickname() {
		return nickname;
	}
	
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	
	public String getProfileurl() {
		return profileURL;
	}
	
	public void setProfileurl(String profileurl) {
		this.profileURL = profileurl;
	}
}
