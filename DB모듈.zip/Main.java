
public class Main {
	public static void main(String[] args) {
		DB_TEST dt = new DB_TEST();
		//dt.login("msa1859","als1tn2!@");
		//dt.Join("abc123", "pw123", "010-2132-8789", "950723-1234122", "abc123@naver.com", "random");
		//dt.check("sunmoon12");
		//dt.setProfile("sunmoon123", "haedali2222", "http//:");
		//dt.setArea("10","20","sunmoon123");
	}
}
