
public class userinfo_DTO {
String id;
String postnumber;
String menu;
String chatnumber;


public String getId() {
	return id;
}

public void setId(String id) {
	this.id = id;
}

public String getPostnumber() {
	return postnumber;
}

public void setPostnumber(String postnumber) {
	this.postnumber = postnumber;
}

public String getMenu() {
	return menu;
}

public void setMenu(String menu) {
	this.menu = menu;
}

public String getChatnumber() {
	return chatnumber;
}

public void setChatnumber(String chatnumber) {
	this.chatnumber = chatnumber;
}
}
