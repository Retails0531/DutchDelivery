
import java.sql.*;
import java.util.Arrays;
import java.util.ArrayList;

public class DB_TEST {

	private Connection con;
	private static final String username = "tnalsa1859";
	private static final String password = "als1tn2!@";
	private static final String url = "jdbc:mysql://database-1.cicqmw0sdjwp.ap-northeast-2.rds.amazonaws.com:3306/dutchdelivery"; //DATABASE 주소
	
	public DB_TEST() {
		try {
			Class.forName("com.mysql.jdbc.Driver"); 
			con = DriverManager.getConnection(url,username,password);
			System.out.println("Driver roading Sucess");
		} catch(Exception e) {
			System.out.println("Driver roading fail");
			try {
				con.close();
			}catch(SQLException e1) {}
		}
	}
	
	public int login(String id, String pw) { //로그인
		String sql = "select * from users where id = ?"; //user의 id를 통해 users테이블에서 id정보를 select
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(sql); 
			pstmt.setString(1, id);
			ResultSet rs = pstmt.executeQuery(); //쿼리문 결과 값을 저장
			if(rs.next()) {
				if(rs.getString("pw").equals(pw)){ //pw칼럼의 값과 입력한 pw값이 일치한다면
					return 1; //1 = 로그인
					}
					else{
 					return 3; //3 = pw 불일치
					}
				
			}
			else {
				return 2; //2 = ID가 없음
			}
		}catch(Exception e) {
			return 0; //0 = 로그인 에러
		} 
		
	}
	
	public int Join(String id, String pw, String phonenumber, String reginumber,String email, String name) { //회원가입
		check(id);//중복확인 메소드를 실행
		if(check(id) == 0) { //check()의 반환 값이 0(중복된 값이 없다.)이면 회원가입 가능
		String sql = "insert into users value(?,?,?,?,?,?,null,null,null)";
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			pstmt.setString(3, phonenumber); 
			pstmt.setString(4, reginumber);
			pstmt.setString(5, email); 
			pstmt.setString(6, name); 
			
			pstmt.executeUpdate(); //DB에 data를 삽입
			return 1; //1 = 회원가입 성공
		}
		catch(Exception e) {
			return 0; //0 = 회원가입 실패
			} 
		}else return 2; //2 = 중복된 id가 존재
	}
	
	public int check(String id) { //중복확인
		String sql = "select EXISTS (select id from users where id = ? limit 1) as success"; //서브쿼리문을 통해 id의 존재여부 확인, success라는 칼럼을 하나 만들어 중복된 id가 있면 1을 출력.
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id); 
			ResultSet rs = pstmt.executeQuery();
			
			if(rs.next()) {
				if(rs.getString("success").equals("1")) {
					return 1; //1 = 중복된 id가 존재
					
				}else {
					return 0; //0 = id 사용가능
				}
			}
			else return 2; //2 = 확인할 data가 존재하지 않음
		}catch(Exception e) {
			return 3; //3 = 중복확인 에러
		} 
		
	}
	
	public int setProfile(String id, String nickname, String profileURL) { //프로필설정 
		String sql = "update users set nickname = ?, profileURL = ? where id = ?"; //회원가입 후 이미 user의 정보가 존재하기 때문에 update를 사용
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, nickname);
			pstmt.setString(2, profileURL);
			pstmt.setString(3, id); 
			pstmt.executeUpdate(); //DB에 data반영
			
			return 1; //프로필 설정 성공
		}catch(Exception e) {
			return 0; //프로필 설정 실패
		} 
		
	}
	
	public int setArea(String x, String y, String id) { //지역설정 ◀◀◀◀◀ 문제 되는놈 
		String sql = "update users set cur_coordinate = ST_GeomFromText('point(? ?)') where id = '?'"; //이미 기존의 user정보가 존재하기 때문에 update문을 사용
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, x);
			pstmt.setString(2, y);
			pstmt.setString(3, id);
			pstmt.executeUpdate(); //DB에 data반영
			
			return 1; //1 = 지역설정 성공

		}catch(Exception e) {
			return 0; //0 = 지역설정 실패
		} 
	}
	
	public int setAddress(String id, String road, String better, String x, String y) { //주소지 저장 (서버>DB) ◀◀◀◀◀
		String sql = "insert into address value(?,?,?,?,ST_GeomFromText('point(? ?)'))";
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1,id);
			pstmt.setString(3,road);
			pstmt.setString(4,better);
			pstmt.setString(5,x);
			pstmt.setString(6,y);
			pstmt.executeUpdate(); //DB에 data반영
			
			return 1; //주소지 저장 성공
		}catch(Exception e) {
			return 0; //주소지 저장 실패
		} 
	}
	
	public ArrayList<address_DTO> getAddress(String id) { //주소지 로깅 정보 보내기 (DB>서버)
		String sql = "select * from address where id =?";
		PreparedStatement pstmt = null;
		ArrayList<address_DTO> list = new ArrayList<address_DTO>(); //주소지 목록을 담을 List 객체 생성
		
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1,id);
			ResultSet rs = pstmt.executeQuery(); //쿼리문 결과 값을 저장
			
			address_DTO ad = new address_DTO(); //address data를 조작하는 address_DTO 객체 생성
			
			while(rs.next()) { 
				ad.setRoad(rs.getString("roadaddress")); //return을 해주기 위해 roadaddress 문자열을 담는다.
				ad.setBetter(rs.getString("betteraddress"));//return을 해주기 위해 betteraddress 문자열을 담는다.	
				list.add(ad); //각각의 문자열을 담은 address_DTO의 클래스들을 List에 추가
			}  
		}catch(Exception e) {
			e.printStackTrace();
		} 
		return list; //도로명 주소, 상세주소가 담긴 List를 서버로 반환
	}
	
	
	
	
	public ArrayList<post_DTO> inquirePost() { //모집글 조회하기 ◀◀◀◀◀
		String sql = "select store_image_url, post_title from store,post where now_time < end_time "; //매장 테이블의 매장이미지 URL과 모집글의 제목을 SELECT
		PreparedStatement pstmt = null;
		ArrayList<post_DTO> list = new ArrayList<post_DTO>();
		
		try {
			pstmt = con.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery(); //쿼리문 결과 값을 저장
			
			post_DTO ps = new post_DTO();
			store_DTO st = new store_DTO();
			
			while(rs.next()) {
				ps.setPosttitle(rs.getString("post_title"));
				st.setStoreiageURL(rs.getString("store_image_url"));
				list.add(ps);	
			}
			
		}catch(Exception e) {
			e.printStackTrace(); 
		} 
		return list; //List에 담은 정보를 서버로 반환
	}
	
	public ArrayList<post_DTO> post(String postnumber) { //모집글 상세보기
		String sql = "select deliveryfee, time, joinPeople, maxPeople, postTitle, postText, pickupAddress from post where post number = ? "; 
		PreparedStatement pstmt = null;
		ArrayList<post_DTO> list = new ArrayList<post_DTO>(); //모집글의 상세정보를 담을 List 객체 생성
		
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1,postnumber); //내가 선택한 모집글의 번호
			ResultSet rs = pstmt.executeQuery(); //쿼리문 결과 값을 저장
			
			post_DTO ps = new post_DTO(); //post data를 조작하는 post_DTO 객체를 생성
			
			while(rs.next()) { //튜플을 한 행씩 읽어들임
			ps.setDeliveryfee(rs.getInt("delivery fee"));
			ps.setTime(rs.getDate("time"));
			ps.setJoinpeople(rs.getInt("joinpeople"));
			ps.setMaxpeople(rs.getInt("maxpeople"));
			ps.setPosttitle(rs.getString("post_title"));
			ps.setPosttext(rs.getString("post_text"));
			ps.setPickupaddress(rs.getString("pick address"));
			list.add(ps); //List에 post_DTO클래스의 정보들을 담음
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		} 
		return list; //List에 담은 정보를 서버로 반환
	}
	
	public ArrayList<post_DTO> searchPost(String word) { //검색 및 필터링
		String sql = "select * from post where post_title = like '%?%'"; //like를 이용하여 검색어를 다치지 않더라도 문자열과 관련한 모집글 들을 보여줌. (% = 내가 입력한 단어뒤에 무엇이든 허용한다)
		PreparedStatement pstmt = null;
		ArrayList<post_DTO> list = new ArrayList<post_DTO>(); //모집글의 제목 정보를 담을 List 객체 생성
		
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, word);
			ResultSet rs = pstmt.executeQuery(); //쿼리문의 결과 값을 저장
			
			post_DTO ps = new post_DTO(); //post data를 조작하는 post_DTO 객체를 생성
			
			while(rs.next()) {
				ps.setPosttitle(rs.getString("post_title"));
				list.add(ps); //List에 post_DTO클래스의 정보들을 담음
			} 
			
		}catch(Exception e) {
			e.printStackTrace();
		} 
		return list; //List에 담은 정보를 서버로 반환
	}
	
	public int regiPost(String postnumber, String storenumber, String deliveryfee, String chatnumber, 
			Date time, String posttitle, String posttext, String id, String pickup) { //모집글 등록
		String sql = "insert into post value(?,?,?,?,?,1,4,?,?,?,?,0)"; //모집글의 상세정보를 설정(삽입)
		PreparedStatement pstmt = null;
		
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, postnumber); 
			pstmt.setString(2, storenumber);
			pstmt.setString(3, deliveryfee);
			pstmt.setString(4, chatnumber);
			pstmt.setDate(5, time);
			pstmt.setString(6, posttitle);
			pstmt.setString(7, posttext);
			pstmt.setString(8, id); 
			pstmt.setString(9, pickup);
			
			pstmt.executeUpdate(); //DB에 data삽입
			
			return 1; //모집글 등록 성공
			
		}catch(Exception e) {
			return 0; //모집글 등록 실패
		} 
	}
	
	public ArrayList<post_DTO> myPost(String id) { //내 모집글 조회 
		String sql = "select * from post where host id = ?"; //해당 id의 유저가 작성한 모집글들을 select
		PreparedStatement pstmt = null;
		ArrayList<post_DTO> list = new ArrayList<post_DTO>(); //모집글의 정보를 담을 List생성
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1,id);
			ResultSet rs = pstmt.executeQuery(); //쿼리문 결과 값을 저장
			
			post_DTO ps = new post_DTO();
			
			while(rs.next()) { 
				ps.setPosttitle(rs.getString("post_title")); //작성했던 모집글의 제목들만 list형태로 보여줌
				list.add(ps); //List에 post_DTO클래스의 정보들을 담음
			} 
		}catch(Exception e) {
			e.printStackTrace();
		}
		return list; //List에 담은 정보를 서버로 반환
	}
	
	public int partPost(String postnumber) { //모집글, 채팅방 참여
		String sql = "update post set joinpeople = joinpeople + 1 where postnumber = ?"; //모집글 및 채팅방 참여할 때의 변화는 참여 인원수밖에 없다고 생각, 그래서 해당 모집글의 참여 인원수만 update해줌
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1,postnumber);
			pstmt.executeUpdate();
			
			return 1; //참여 성송
		}catch(Exception e) {
			return 0; //참여 실패
		} 
	}
	
	public ArrayList<users_DTO> profileInfo(String id) { //내 프로필 정보
		String sql = "select * from users where id = ?"; //해당 id와 관련된 유저의 닉네임, profileURL의 정보를 select하여 반환해준다.
		PreparedStatement pstmt = null;
		ArrayList<users_DTO> list = new ArrayList<users_DTO>();
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			ResultSet rs = pstmt.executeQuery(); 
			
			users_DTO us = new users_DTO();
			
			while(rs.next()) {
			us.setNickname(rs.getString("nickname"));
			us.setProfileurl(rs.getString("progfileURL"));	
			list.add(us);
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
		
 public ArrayList<userinfo_DTO> chatList(String id) { //참여중인 채팅방 목록
	String sql = "select * from user info where id = ?"; //해당 id가 참여중인 chatnumber를 select하여 반환해준다.
	PreparedStatement pstmt = null;
	ArrayList<userinfo_DTO> list = new ArrayList<userinfo_DTO>();
	
	try {
		pstmt = con.prepareStatement(sql);
		pstmt.setString(1,id);
		ResultSet rs = pstmt.executeQuery(); //쿼리문 결과 값 저장
		
		userinfo_DTO ui = new userinfo_DTO();
	
		while(rs.next()) { 
			ui.setChatnumber(rs.getString("chat number"));
			list.add(ui);
		}
	}catch(Exception e) {
		e.printStackTrace();
		} 
	return list;
	}
}
