
public class store_DTO {
String storenumber;
String storename;
String storebetteraddress;
String onerid;
String storeimageURL;

public String getStorenumber() {
	return storenumber;
}

public void setStorenumber(String storenumber) {
	this.storenumber = storenumber;
}

public String getStorename() {
	return storename;
}

public void setStorename(String storename) {
	this.storename = storename;
}

public String getStorebetteraddress() {
	return storebetteraddress;
}

public void setStorebetteraddress(String storebetteraddress) {
	this.storebetteraddress = storebetteraddress;
}

public String getOnerid() {
	return onerid;
}

public void setOnerid(String onerid) {
	this.onerid = onerid;
}

public String getStoreimageURL() {
	return storeimageURL;
}

public void setStoreiageURL(String storeimageURL) {
	this.storeimageURL = storeimageURL;
}
}
