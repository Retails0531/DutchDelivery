
public class address_DTO {
		String id;
		String road;
		String better;
		
		public void setId() {
			this.id = id;
		}
		
		public String getRoad() {
			return road;
		}
		
		public void setRoad(String road) {
			this.road = road;
		}
		
		public String getBetter() {
			return better;
		}
		
		public void setBetter(String better) {
			this.better = better;
		}

}
