import java.sql.Date;

public class post_DTO {
	
		String postnumber, storenumber,chatnumber,posttitle,posttext,pickupaddress;
		int deliveryfee, joinpeople, maxpeople;
		Date time;
		
		public String getPostnumber() {
			return postnumber;
		}
		
		public void setPostnumber(String postnumber) {
			this.postnumber = postnumber;
		}
		
		public String getStorenumber() {
			return storenumber;
		}
		
		public void setStorenumber(String storenumber) {
			this.storenumber = storenumber;
		}
		
		public int getDeliveryfee() {
			return deliveryfee;
		}
		
		public void setDeliveryfee(int deliveryfee) {
			this.deliveryfee = deliveryfee;
		}
		
		public Date getTime() {
			return time;
		}
		
		public void setTime(Date time) {
			this.time = time;
		}
		
		public String getChatnumber() {
			return chatnumber;
		}
		
		public void setChatnumber(String chatnumber) {
			this.chatnumber = chatnumber;
		}
		
		public int getJoinpeople() {
			return joinpeople;
		}
		
		public void setJoinpeople(int joinpeople) {
			this.joinpeople = joinpeople;
		}
		
		public int getMaxpeople() {
			return maxpeople;
		}
		
		public void setMaxpeople(int maxpeople) {
			this.maxpeople = maxpeople;
		}
		
		public String getPosttitle() {
			return posttitle;
		}
		
		public void setPosttitle(String posttitle) {
			this.posttitle = posttitle;
		}
		
		public String getPosttext() {
			return posttext;
		}
		
		public void setPosttext(String posttext) {
			this.posttext = posttext;
		}
		
		public String getPickupaddress() {
			return pickupaddress;
		}
		
		public void setPickupaddress(String pickupaddress) {
			this.pickupaddress = pickupaddress;
		}
	
}
